package com.example.dearfutureme.Model

class Images (
    val data: List<Image>
)