package com.example.dearfutureme.Model

class CapsuleResponse(
    val  data: List<Capsules>
)