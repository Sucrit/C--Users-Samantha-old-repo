package com.example.dearfutureme.Model

data class LogoutResponse(
    val message: String
)
